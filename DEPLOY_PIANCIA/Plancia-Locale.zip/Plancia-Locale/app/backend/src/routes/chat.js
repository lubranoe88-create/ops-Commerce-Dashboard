import { Router } from "express";
import { validateChat } from "../middleware/validateChat.js";
import { completeChat } from "../services/openrouter.js";
import { listChatModels } from "../services/chatModels.js";
import { injectAutomaticRecall } from "../services/atlasRecall.js";

export const chatRouter = Router();

chatRouter.get("/models", (_req, res) => {
  res.json(listChatModels());
});

chatRouter.post("/", validateChat, async (req, res) => {
  try {
    const attached = injectAutomaticRecall(req.chat.prompt, req.chat.prompt);
    const result = await completeChat({ ...req.chat, prompt: attached.prompt });
    return res.json({
      content: result.content,
      model: result.model,
      usage: result.usage,
      role: "synthesis_ranking",
    });
  } catch (err) {
    const status = err.status && Number.isInteger(err.status) ? err.status : 502;
    const message = err.upstream
      ? err.message
      : "Failed to complete chat request";
    return res.status(status).json({ error: message });
  }
});
