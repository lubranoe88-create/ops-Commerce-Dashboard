# Soft update: refresh app\ from GitHub main zipball. Never abort launch on failure.
$ErrorActionPreference = "Continue"
$RepoSlug = "lubranoe88-create/ops-Commerce-Dashboard"
$Branch = "main"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$App = Join-Path $Root "app"
$stampFile = Join-Path $Root ".plancia-commit"
try {
  Write-Host "Controllo aggiornamenti GitHub..." -ForegroundColor Cyan
  $headers = @{ "User-Agent" = "plancia-locale-pack"; "Accept" = "application/vnd.github+json" }
  $sha = [string](Invoke-RestMethod -Uri "https://api.github.com/repos/$RepoSlug/commits/$Branch" -Headers $headers -TimeoutSec 20).sha
  if (-not $sha) { throw "SHA assente" }
  $prev = if (Test-Path $stampFile) { (Get-Content $stampFile -Raw).Trim() } else { "" }
  if ($prev -eq $sha) {
    Write-Host "Gia' aggiornato." -ForegroundColor DarkGray
    exit 0
  }
  Write-Host "Download aggiornamento..." -ForegroundColor Cyan
  $tmp = Join-Path $env:TEMP ("plancia-pack-" + [guid]::NewGuid().ToString("n"))
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null
  $zip = Join-Path $tmp "main.zip"
  Invoke-WebRequest -Uri "https://api.github.com/repos/$RepoSlug/zipball/$Branch" -Headers $headers -OutFile $zip -TimeoutSec 600
  Expand-Archive -LiteralPath $zip -DestinationPath $tmp -Force
  $extracted = Get-ChildItem -LiteralPath $tmp -Directory | Select-Object -First 1
  if (-not $extracted) { throw "ZIP vuoto" }
  $envPath = Join-Path $App "backend\.env"
  $envBackup = $null
  if (Test-Path $envPath) { $envBackup = Get-Content $envPath -Raw }
  # Copy repo into app\ (backend, public, DEPLOY_PIANCIA, etc.)
  foreach ($name in @("backend","public","DEPLOY_PIANCIA","docs")) {
    $src = Join-Path $extracted.FullName $name
    if (Test-Path $src) {
      $dest = Join-Path $App $name
      Copy-Item -LiteralPath $src -Destination $dest -Recurse -Force
    }
  }
  if ($null -ne $envBackup) {
    $bd = Join-Path $App "backend"
    if (-not (Test-Path $bd)) { New-Item -ItemType Directory -Force -Path $bd | Out-Null }
    Set-Content -LiteralPath $envPath -Value $envBackup -NoNewline
  }
  Set-Content -LiteralPath $stampFile -Value $sha -NoNewline
  Write-Host "Aggiornamento completato." -ForegroundColor Green
  Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
} catch {
  Write-Host "AVVISO: aggiornamento non disponibile ($($_.Exception.Message)). Uso file locali." -ForegroundColor Yellow
}
