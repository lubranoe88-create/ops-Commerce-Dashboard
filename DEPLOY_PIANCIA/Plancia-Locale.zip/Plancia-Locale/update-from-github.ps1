# Compatibility wrapper — real logic lives in forza-aggiornamento.ps1
& "$PSScriptRoot\forza-aggiornamento.ps1" @args
exit $LASTEXITCODE
